#!/bin/bash
# 阿萨尔掉线守护 v1.2 (2026-11-08)
# v1.2 改动(依据2026-11-08社区调研): 被踢/等扫码期间完全停止自动重启
#   —— 会话已被服务端作废,任何定时重试都是"频繁无效登录",只会加重风控
#   —— 原v1.1的"被踢标记超6小时允许再试"已移除,被踢后只等人工扫码
#   —— 人工恢复途径: 扫码后 connected 自动清标记;或 rm /root/.guard_kicked
# 规则1: QQ进程死了且无近期二维码 -> 自动拉起(崩溃恢复,保留)
# 规则2: WS断开+未被踢标记 -> 尝试重启NapCat免扫码恢复(登录态可能还在,保留)
# 规则3: 重启后仍出新款二维码(=真被踢) -> 记被踢标记,此后不再自动重启,等人工扫码
# 规则4: 每小时最多重启3次,重启后冷却5分钟;登录成功(connected)自动清被踢标记
LOG=/root/bot.log
QR=/root/Napcat/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.png
STATE=/root/guard_status.txt
LAST_RESTART=/root/.guard_last
CNT_FILE=/root/.guard_cnt
KICKED=/root/.guard_kicked
TS() { stat -c %Y "$1" 2>/dev/null || echo 0; }
start_qq() {
  cd /root && nohup xvfb-run -a /root/Napcat/opt/QQ/qq --no-sandbox --disable-gpu --disable-software-rasterizer --disable-dev-shm-usage --js-flags=--max-old-space-size=512 >> /root/napcat-restart.log 2>&1 &
}
can_restart() {
  NOW=$(date +%s)
  LR=$(cat "$LAST_RESTART" 2>/dev/null || echo 0)
  [ $(( NOW - LR )) -lt 300 ] && return 1
  H=$(date +%H)
  read C H2 < "$CNT_FILE" 2>/dev/null || { C=0; H2=$H; }
  [ "$H" != "$H2" ] && C=0
  [ "$C" -ge 3 ] && return 1
  echo "$((C+1)) $H" > "$CNT_FILE"
  echo "$NOW" > "$LAST_RESTART"
  return 0
}
echo "$(date '+%m-%d %H:%M:%S') 守护v1.2启动" >> "$STATE"
while true; do
  sleep 60
  pgrep -f "remote_ct[l].sh" >/dev/null || { echo "$(date '+%m-%d %H:%M:%S') 看护:遥控不在,拉起" >> "$STATE"; cd /root && setsid nohup bash /root/remote_ctl.sh >> /root/remote_ctl.log 2>&1 & }
  LAST=$(grep "WebSocket for Bot 3427943187" "$LOG" 2>/dev/null | tail -1)
  case "$LAST" in
    *connected*)
      [ -f "$KICKED" ] && rm -f "$KICKED" && echo "$(date '+%m-%d %H:%M:%S') 已重新上线,清除被踢标记" >> "$STATE"
      continue
      ;;
  esac
  QQ_N=$(pgrep -fc "opt/QQ/[q]q" 2>/dev/null)
  if [ "$QQ_N" = "0" ] || [ -z "$QQ_N" ]; then
    AGE=999999
    [ -f "$QR" ] && AGE=$(( $(date +%s) - $(TS "$QR") ))
    if [ $AGE -gt 600 ]; then
      if can_restart; then
        echo "$(date '+%m-%d %H:%M:%S') QQ进程消失,自动拉起" >> "$STATE"
        start_qq
      fi
    fi
    continue
  fi
  # QQ活着但WS不在connected态
  # v1.2: 被踢标记存在时,不做任何自动重启,静等人工扫码
  if [ -f "$KICKED" ]; then
    continue
  fi
  AGE=999999
  [ -f "$QR" ] && AGE=$(( $(date +%s) - $(TS "$QR") ))
  LR=$(cat "$LAST_RESTART" 2>/dev/null || echo 0)
  QRT=$(TS "$QR")
  if [ $AGE -lt 300 ]; then
    # 新鲜二维码: 刚被踢或刚重启出来,先标记(若此码在最近一次重启之后出现,基本坐实被踢)
    if [ "$QRT" -gt "$LR" ] && [ "$LR" != "0" ]; then
      echo "$(date +%s)" > "$KICKED"
      echo "$(date '+%m-%d %H:%M:%S') 重启后仍出新二维码: 确认被腾讯踢线,标记后等人工扫码(v1.2不再自动重试)" >> "$STATE"
    fi
    continue
  fi
  if can_restart; then
    echo "$(date '+%m-%d %H:%M:%S') WS断开,尝试重启NapCat免扫码恢复" >> "$STATE"
    pkill -f "opt/QQ/qq" 2>/dev/null
    sleep 3
    start_qq
  fi
done
