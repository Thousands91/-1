#!/bin/bash
echo "① 大脑进程:"
pgrep -f 'venv/bin/python main.py' || echo "   ✗ 没在跑"

echo "② 8080 监听:"
grep -qi ':1F90' /proc/net/tcp /proc/net/tcp6 2>/dev/null && echo "   ✅ 在监听" || echo "   ✗ 没监听"

echo "③ NapCat 进程:"
pgrep -f 'opt/QQ/qq' >/dev/null && echo "   ✅ 在跑" || echo "   ✗ 没在跑"

echo "④ 模拟 NapCat 连大脑:"
cd /root/bot/bot && /root/bot/venv/bin/python - <<'PY'
import asyncio, json
async def m():
    try:
        import websockets
    except ImportError:
        import aiohttp
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("ws://127.0.0.1:8080/onebot/v11/ws",
                    headers={"X-Self-ID":"99999","X-Client-Role":"Universal"},
                    max_msg_size=0) as ws:
                print("   ✅ 连上了，大脑正常")
                await ws.send_str(json.dumps({"action":"get_login_info","params":{},"echo":"x"}))
                r = await asyncio.wait_for(ws.receive(), timeout=10)
                print("   收到:", str(r.data)[:100])
        return
    async with websockets.connect("ws://127.0.0.1:8080/onebot/v11/ws",
            extra_headers={"X-Self-ID":"99999","X-Client-Role":"Universal"}) as ws:
        print("   ✅ 连上了，大脑正常")
        await ws.send(json.dumps({"action":"get_login_info","params":{},"echo":"x"}))
        print("   收到:", str(await asyncio.wait_for(ws.recv(), timeout=10))[:100])
asyncio.run(m())
PY

echo "⑤ 模型 Key 配置:"
grep -qE '^OPENAI_API_KEY=.+' /root/bot/bot/.env && echo "   ✅ 有" || echo "   ✗ 缺"
