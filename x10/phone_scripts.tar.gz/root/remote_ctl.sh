#!/bin/bash
termux-wake-lock 2>/dev/null
REPO=/root/asar-sync
LOG=/root/remote_ctl.log
QR=/root/Napcat/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.png
BASE="https://api.github.com/repos/Thousands91/-1/contents/remote"
RAWBASE="https://raw.githubusercontent.com/Thousands91/-1/main/remote"
CMD_URL="$BASE/cmd.txt"
OUT_URL="$BASE/out.txt"
PBOX=/root/.remote_pending
mkdir -p "$PBOX"
if [ -f /root/.remote_pid ]; then
  OP=$(cat /root/.remote_pid 2>/dev/null)
  [ -n "$OP" ] && [ "$OP" != "$$" ] && kill -0 "$OP" 2>/dev/null && exit 0
fi
echo $$ > /root/.remote_pid
get_tok() {
  printf 'protocol=https\nhost=github.com\n\n' | timeout 10 git credential fill 2>/dev/null | sed -n 's/^password=//p' | head -1
}
TOK=$(get_tok)
[ -n "$TOK" ] || TOK=$(grep -oE 'ghp_[A-Za-z0-9]+' /root/.git-credentials 2>/dev/null | head -1)
cd "$REPO" || exit 1
LAST=0
C=0
[ -f /root/.remote_last ] && LAST=$(cat /root/.remote_last)

run_task() {
  echo "$1" > /root/.remote_last
  LAST=$1
  O="$PBOX/task_$1.txt"
  { echo "===== 任务$1 $(date '+%m-%d %H:%M:%S') ====="; echo "--- 命令 ---"; tail -n +2 "$2"; echo "--- 输出 ---"; tail -n +2 "$2" | timeout 90 bash 2>&1; } > "$O"
  cat "$O" >> "$LOG"
}

api_report() {
  ls "$PBOX" >/dev/null 2>&1 || return 0
  F=$(ls -A "$PBOX" 2>/dev/null); [ -n "$F" ] || return 0
  : > /tmp/remote_bundle.txt
  for f in $F; do echo "<<<$f>>>" >> /tmp/remote_bundle.txt; cat "$PBOX/$f" >> /tmp/remote_bundle.txt; done
  [ -n "$TOK" ] || TOK=$(get_tok)
  [ -n "$TOK" ] || { echo "[$(date '+%m-%d %H:%M')] report:无token,留待下轮" >> "$LOG"; return 1; }
  SHA=$(timeout 30 curl -s -H "Authorization: token $TOK" "$OUT_URL?cb=$(date +%s)" | tr -d ' ' | grep -o '"sha":"[^"]*"' | head -1 | cut -d'"' -f4)
  B64=$(base64 -w0 /tmp/remote_bundle.txt) || return 1
  R=$(timeout 60 curl -s -X PUT -H "Authorization: token $TOK" -d "{\"message\":\"遥控输出(API) $(date '+%m-%d %H:%M')\",\"content\":\"$B64\"${SHA:+,\"sha\":\"$SHA\"}}" "$OUT_URL")
  if echo "$R" | grep -q '"content"'; then
    rm -f "$PBOX"/*
    echo "[$(date '+%m-%d %H:%M')] report:API回传成功" >> "$LOG"
  else
    echo "[$(date '+%m-%d %H:%M')] report:API回传失败:$(echo "$R" | head -c 120)" >> "$LOG"
  fi
}

NAP_FUSE=/root/.napcat_pulls
restart_napcat() {
  NOW=$(date +%s)
  touch "$NAP_FUSE"
  : > /tmp/napf
  while IFS= read -r t; do
    [ -n "$t" ] && [ $((NOW - t)) -lt 86400 ] && echo "$t" >> /tmp/napf
  done < "$NAP_FUSE"
  CNT=$(wc -l < /tmp/napf)
  if [ "$CNT" -ge 3 ]; then
    echo "[$(date '+%m-%d %H:%M')] 保险丝熔断:NapCat 24h内已自动拉起${CNT}次,停止自动重启,需人工排查" >> "$LOG"
    return 1
  fi
  echo "$NOW" >> /tmp/napf && cp /tmp/napf "$NAP_FUSE"
  echo "[$(date '+%m-%d %H:%M')] 看护:自动拉起NapCat(24h内第$((CNT+1))次)" >> "$LOG"
  pkill -f "opt/QQ/qq" 2>/dev/null; sleep 3
  cd /root/Napcat && nohup xvfb-run -a /root/Napcat/opt/QQ/qq --no-sandbox >> /root/napcat-restart.log 2>&1 &
  cd "$REPO"
}


put_status() {
  FORCED="$1"
  QQ_S=$(pgrep -fc "opt/QQ/[q]q" 2>/dev/null); [ -z "$QQ_S" ] && QQ_S=0
  BOT_S=$(pgrep -f "mai[n].py" >/dev/null 2>&1 && echo 在 || echo 不在)
  LOG_S=$(timeout 20 bash /root/logincheck.sh 2>/dev/null | grep -c "\[未登录\]\|\[掉线\]")
  [ "$LOG_S" = "0" ] && LOGIN=在线 || LOGIN=掉线
  MEM_S=$(free -m 2>/dev/null | awk 'NR==2{print $3"M/"$2"M"}')
  CORE="QQ:$QQ_S bot:$BOT_S 登录:$LOGIN 内存:$MEM_S"
  if [ "$FORCED" != "force" ]; then
    [ -f /root/.last_status_core ] && [ "$(cat /root/.last_status_core)" = "$CORE" ] && return 0
  fi
  echo "$CORE" > /root/.last_status_core
  TXT="[$(date '+%m-%d %H:%M')] $CORE"
  SHA=$(timeout 30 curl -s -H "Authorization: token $TOK" "$BASE/status.txt" | tr -d ' ' | grep -o '"sha":"[^"]*"' | head -1 | cut -d'"' -f4)
  B64S=$(printf '%s' "$TXT" | base64 -w0)
  R=$(timeout 60 curl -s -X PUT -H "Authorization: token $TOK" -d "{\"message\":\"status\",\"content\":\"$B64S\"${SHA:+,\"sha\":\"$SHA\"}}" "$BASE/status.txt")
  echo "$R" | grep -q '"content"' || echo "[$(date '+%m-%d %H:%M')] status上传失败" >> "$LOG"
}

while true; do
  [ -n "$TOK" ] || TOK=$(get_tok)
  # v4.4 滚动槽位协议:任务写 cmd_月日_时分.txt(5分钟槽),路径不重复,CDN缓存无法钉死
  E5=$(( $(date +%s) / 300 * 300 ))
  CUR=$(date -d @$E5 +%m%d_%H%M 2>/dev/null)
  PRV=$(date -d @$((E5-300)) +%m%d_%H%M 2>/dev/null)
  BEST=""; BESTID=$LAST
  for U in "cmd_$CUR.txt" "cmd_$PRV.txt" "cmd.txt"; do
    RAW=$(timeout 15 curl -s "$RAWBASE/$U?cb=$(date +%s%N)")
    RID=$(printf '%s\n' "$RAW" | head -1 | tr -dc 0-9)
    if [ -n "$RID" ] && [ "$RID" -gt "$BESTID" ]; then BESTID=$RID; BEST="$RAW"; fi
  done
  [ $((C % 4)) -eq 0 ] && echo "[$(date '+%m-%d %H:%M')] intake:槽位=$CUR/$PRV 命中ID=$BESTID" >> "$LOG"
  if [ -n "$BEST" ]; then
    printf '%s\n' "$BEST" > "/tmp/remote_cmd_$BESTID.txt"
    run_task "$BESTID" "/tmp/remote_cmd_$BESTID.txt"
    api_report
  fi
  api_report
  C=$((C+1))
  # 看护检查每 4 轮跑一次（约 60s），任务拉取每轮都跑（15s）——拉任务轻、看护重，分开节流
  if [ $((C % 4)) -eq 0 ]; then
  ST=$(timeout 20 bash /root/logincheck.sh 2>/dev/null | grep -c "\[未登录\]\|\[掉线\]")
  if [ "$ST" = "1" ] && [ -f "$QR" ]; then
    NOW=$(date +%s); MT=$(stat -c %Y "$QR" 2>/dev/null || echo "$NOW")
    AGE=$((NOW - MT))
    if [ "$AGE" -gt 600 ]; then
      echo "[$(date '+%m-%d %H:%M')] 看护：未登录且码${AGE}s未刷新，尝试重启NapCat" >> "$LOG"
      restart_napcat
    fi
  fi
  pgrep -f "opt/QQ/qq" >/dev/null || { echo "[$(date '+%m-%d %H:%M')] 看护：NapCat不在" >> "$LOG"; restart_napcat; }
  pgrep -f "main.py" >/dev/null || { echo "[$(date '+%m-%d %H:%M')] 看护：大脑不在，拉起" >> "$LOG"; cd /root/bot/bot && nohup /root/bot/venv/bin/python main.py > /root/bot.log 2>&1 & cd "$REPO"; }
  [ $((C % 40)) -eq 0 ] && echo "[$(date '+%m-%d %H:%M')] 心跳:循环正常,LAST=$LAST" >> "$LOG"
  if [ $((C % 40)) -eq 0 ]; then put_status force; else put_status; fi
  fi
  sleep 15
done
