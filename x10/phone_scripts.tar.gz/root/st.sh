#!/bin/bash
if ! pgrep -f "opt/QQ/qq" > /dev/null; then
  echo "QQ未运行，正在启动..."
  nohup xvfb-run -a /root/Napcat/opt/QQ/qq --no-sandbox --disable-gpu --disable-software-rasterizer --disable-dev-shm-usage --js-flags=--max-old-space-size=512 > /root/napcat.log 2>&1 &
  sleep 20
else
  echo "QQ进程: 在运行"
fi
CRED=$(curl -s -m 10 -X POST http://127.0.0.1:6099/api/auth/login -H "Content-Type: application/json" -d '{"hash":"'$(printf "072bb0cc960e.napcat" | sha256sum | cut -d' ' -f1)'"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['data']['Credential'])" 2>/dev/null)
if [ -z "$CRED" ]; then echo "WebUI登录失败(接口返回空)，可能QQ刚启动还在初始化，等30秒重跑本脚本"; exit 0; fi
curl -s -m 20 -X POST "http://127.0.0.1:6099/api/QQLogin/CheckLoginStatus" -H "Content-Type: application/json" -H "Authorization: Bearer $CRED" -d '{}'
echo
