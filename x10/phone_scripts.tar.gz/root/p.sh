#!/bin/sh
echo "$2" | adb pair "192.168.31.28:$1" && adb connect "192.168.31.28:$3"
adb devices
