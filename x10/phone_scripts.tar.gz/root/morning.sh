#!/bin/bash
echo "① 大脑进程:"
if pgrep -f 'venv/bin/python main.py' >/dev/null; then echo "   ✅ 在跑"
else
  echo "   ✗ 没在跑，重启中..."
  cd /root/bot/bot && nohup /root/bot/venv/bin/python main.py > bot.log 2>&1 &
  sleep 8
  pgrep -f 'venv/bin/python main.py' >/dev/null && echo "   ✅ 已重启" || echo "   ✗ 重启失败，把 bot.log 发我"
fi

echo "② NapCat 进程:"
if pgrep -f 'opt/QQ/qq' >/dev/null; then echo "   ✅ 在跑"
else
  echo "   ✗ 没在跑，重启中..."
  cd /root/Napcat && nohup xvfb-run -a /root/Napcat/opt/QQ/qq --no-sandbox --disable-gpu --disable-software-rasterizer --disable-dev-shm-usage --js-flags=--max-old-space-size=512 > /root/napcat.log 2>&1 &
  sleep 12
  pgrep -f 'opt/QQ/qq' >/dev/null && echo "   ✅ 已重启" || echo "   ✗ 重启失败，把 napcat.log 发我"
fi

echo "③ 大脑连通性实测（发@消息等回复，约半分钟）:"
/root/bot/venv/bin/python - <<'PY'
import asyncio, json, aiohttp
async def m():
    try:
        async with aiohttp.ClientSession() as s:
            async with s.ws_connect("ws://127.0.0.1:8080/onebot/v11/ws",
                    headers={"X-Self-ID":"99999","X-Client-Role":"Universal"},
                    max_msg_size=0) as ws:
                ev = {"time":1793250000,"self_id":99999,"post_type":"message",
                      "message_type":"group","sub_type":"normal",
                      "group_id":33333,"user_id":22222,"message_id":900001,
                      "message":[{"type":"at","data":{"qq":"99999"}},
                                 {"type":"text","data":{"text":" 你好，你是谁？"}}],
                      "raw_message":"[CQ:at,qq=99999] 你好，你是谁？","font":0,
                      "sender":{"user_id":22222,"nickname":"测试员","role":"member"}}
                await ws.send_str(json.dumps(ev))
                for _ in range(6):
                    r = await asyncio.wait_for(ws.receive(), timeout=90)
                    d = json.loads(r.data)
                    if d.get("action") == "get_group_member_list":
                        await ws.send_str(json.dumps({"status":"ok","retcode":0,
                            "echo":d.get("echo"),
                            "data":[{"user_id":22222,"nickname":"测试员","card":"测试员"}]}))
                    elif d.get("action") in ("send_msg","send_group_msg","send_private_msg"):
                        txt = "".join(x.get("data",{}).get("text","")
                                      for x in d["params"]["message"] if x.get("type")=="text")
                        print("   ✅ 阿萨尔的回复:", txt[:60]); return
                print("   ✗ 连上了但没等到回复，把输出发我")
    except Exception as e:
        print("   ✗ 连不上:", type(e).__name__, e)
asyncio.run(m())
PY

echo ""
echo "===== ①②③ 全部 ✅ 就执行下面这条拿新码，立刻扫 ====="
echo 'cp /root/Napcat/opt/QQ/resources/app/app_launcher/napcat/cache/qrcode.png "/sdcard/Pictures/NapCat-$(date +%H%M%S).png"'
