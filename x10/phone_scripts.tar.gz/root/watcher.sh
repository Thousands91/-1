#!/bin/sh
TOKEN="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"
BASE="https://api.github.com/repos/Thousands91/qq-bot/contents"
LOG="/root/watcher.log"
echo "== watcher start: $(date) ==" >> "$LOG"
while true; do
  RESP=$(curl -s -m 10 -H "Authorization: token $TOKEN" "$BASE/pin.txt?t=$(date +%s)")
  B64=$(printf '%s' "$RESP" | sed -n 's/.*"content": *"\([^"]*\)".*/\1/p' | head -1)
  TXT=$(printf '%s' "$B64" | base64 -d 2>/dev/null)
  case "$TXT" in
    s*\ PAIR*|s*\ RUN*)
      SER=$(printf '%s' "$TXT" | awk '{print $1}')
      if [ "$SER" != "$(cat /root/.ser 2>/dev/null)" ]; then
        echo "$SER" > /root/.ser
        echo ">> 收到任务: $TXT" >> "$LOG"
        case "$TXT" in
          *" PAIR "*)
            DP=$(printf '%s' "$TXT" | awk '{print $3}')
            PC=$(printf '%s' "$TXT" | awk '{print $4}')
            MP=$(printf '%s' "$TXT" | awk '{print $5}')
            OUT=$(printf '%s\n' "$PC" | adb pair "192.168.31.28:$DP" 2>&1; adb connect "192.168.31.28:$MP" 2>&1; adb devices 2>&1)
            ;;
          *" RUN "*)
            OUT=$(sh -c "$(printf '%s' "$TXT" | cut -d' ' -f3-)" 2>&1)
            ;;
        esac
        echo "$OUT" >> "$LOG"
        SHA=$(curl -s -m 10 -H "Authorization: token $TOKEN" "$BASE/result.txt" | sed -n 's/.*"sha": *"\([0-9a-f]\{40\}\)".*/\1/p' | head -1)
        CB=$(printf '%s' "$OUT" | base64 -w0)
        if [ -n "$SHA" ]; then
          DATA="{\"message\":\"r$(date +%s)\",\"content\":\"$CB\",\"sha\":\"$SHA\"}"
        else
          DATA="{\"message\":\"r$(date +%s)\",\"content\":\"$CB\"}"
        fi
        curl -s -m 15 -X PUT -H "Authorization: token $TOKEN" -H "Accept: application/vnd.github+json" -d "$DATA" "$BASE/result.txt" > /dev/null
        echo "<< 结果已回传 $(date)" >> "$LOG"
      fi
      ;;
  esac
  sleep 3
done
