#!/bin/bash
termux-wake-lock
nohup proot-distro login ubuntu -- bash -c 'cd /root && nohup bash /root/remote_ctl.sh >> /root/remote_ctl.log 2>&1 & nohup bash /root/azar_guard.sh >> /root/azar_guard.log 2>&1 & cd /root/Napcat && nohup xvfb-run -a /root/Napcat/opt/QQ/qq --no-sandbox >> /root/napcat-restart.log 2>&1 & cd /root/bot/bot && nohup /root/bot/venv/bin/python main.py > /root/bot.log 2>&1' > /dev/null 2>&1 &
echo ==服务已全部拉起==
echo 以后手机重启后: 打开Termux输入 bash start_all.sh 即可
