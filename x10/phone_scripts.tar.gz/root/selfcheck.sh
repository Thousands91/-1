#!/bin/bash
# 阿萨尔自检 v1 (2026-11-08)
echo "== 自检 $(date '+%F %H:%M:%S') =="
echo "-- 服务 --"
QQ_N=$(pgrep -fc "opt/QQ/[q]q" 2>/dev/null); echo "QQ进程数: ${QQ_N:-0}"
pgrep -f "mai[n].py" >/dev/null && echo "bot: 在" || echo "bot: 不在"
pgrep -f "remote_ct[l].sh" >/dev/null && echo "遥控: 在" || echo "遥控: 不在"
pgrep -f "azar_guar[d].sh" >/dev/null && echo "守护: 在" || echo "守护: 不在"
echo "-- 登录态 --"
bash /root/logincheck.sh 2>/dev/null | tail -2
echo "-- 资源 --"
free -m 2>/dev/null | awk 'NR==2{print "内存: "$3"M 已用 / "$2"M 总量"}'
echo "-- bot.log 尾3行 --"
tail -3 /root/bot.log 2>/dev/null
echo "-- guard_status 尾3行 --"
tail -3 /root/guard_status.txt 2>/dev/null
echo "== 自检完 =="
